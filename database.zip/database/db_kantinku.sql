DROP DATABASE IF EXISTS db_kantinku;
CREATE DATABASE db_kantinku;
USE db_kantinku;

-- penjual (punya kedai) dan pelanggan
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(50) NOT NULL,
  role VARCHAR(10) NOT NULL,
  nama_stan VARCHAR(100),
  rekening VARCHAR(150),
  qris VARCHAR(100)
);

CREATE TABLE menu (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_penjual INT NOT NULL,
  nama_menu VARCHAR(100) NOT NULL,
  kategori VARCHAR(20) NOT NULL,
  harga INT NOT NULL,
  stok INT NOT NULL,
  foto VARCHAR(100) NOT NULL DEFAULT '',
  FOREIGN KEY (id_penjual) REFERENCES users(id) ON DELETE CASCADE
);

-- metode: qris / transfer. bayar: belum -> dibayar (bukti dikirim) -> lunas (dikonfirmasi penjual)
CREATE TABLE pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(10) NOT NULL UNIQUE,
  id_user INT NOT NULL,
  id_penjual INT NOT NULL,
  tanggal DATE NOT NULL,
  jam_ambil VARCHAR(11) NOT NULL,
  total INT NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'menunggu',
  catatan VARCHAR(200),
  metode VARCHAR(10) NOT NULL DEFAULT 'qris',
  bayar VARCHAR(10) NOT NULL DEFAULT 'belum',
  bukti VARCHAR(100) NOT NULL DEFAULT '',
  FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (id_penjual) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE detail_pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_pesanan INT NOT NULL,
  id_menu INT NOT NULL,
  nama_menu VARCHAR(100) NOT NULL,
  harga INT NOT NULL,
  jumlah INT NOT NULL,
  FOREIGN KEY (id_pesanan) REFERENCES pesanan(id) ON DELETE CASCADE
);

-- Data contoh (nomor rekening di bawah fiktif, ganti dengan data asli kalau dipakai)
INSERT INTO users (id, username, email, password, role, nama_stan, rekening) VALUES
(1, 'bu_ratna', 'ratna@gmail.com', 'ratna123', 'penjual', 'Kedai Bu Ratna', 'DANA 0812-0000-0001 a.n. Bu Ratna'),
(2, 'pak_hadi', 'hadi@gmail.com', 'hadi456', 'penjual', 'Kedai Pak Hadi', 'GoPay 0812-0000-0002 a.n. Pak Hadi'),
(3, 'bu_wati', 'wati@gmail.com', 'wati789', 'penjual', 'Kedai Bu Wati', 'BCA 1234567890 a.n. Bu Wati'),
(4, 'pak_joko', 'joko@gmail.com', 'joko321', 'penjual', 'Kedai Pak Joko', 'ShopeePay 0812-0000-0004 a.n. Pak Joko'),
(5, 'mahasiswa1', 'mhs1@gmail.com', 'mhs111', 'pelanggan', NULL, NULL),
(6, 'mahasiswa2', 'mhs2@gmail.com', 'mhs222', 'pelanggan', NULL, NULL);

INSERT INTO menu (id, id_penjual, nama_menu, kategori, harga, stok, foto) VALUES
(1, 1, 'Lontong Opor Ayam', 'Makanan', 13000, 20, 'lontong-opor-ayam.jpg'),
(2, 1, 'Nasi Pecel', 'Makanan', 10000, 25, 'nasi-pecel.jpg'),
(3, 1, 'Gado-gado', 'Makanan', 11000, 20, 'gado-gado.jpg'),
(4, 1, 'Nasi Uduk Komplit', 'Makanan', 12000, 20, 'nasi-uduk-komplit.jpg'),
(5, 1, 'Tahu Walik', 'Camilan', 8000, 30, 'tahu-walik.jpg'),
(6, 1, 'Peyek Kacang', 'Camilan', 3000, 30, 'peyek-kacang.jpg'),
(7, 2, 'Ayam Geprek', 'Makanan', 15000, 30, 'ayam-geprek.jpg'),
(8, 2, 'Ayam Kocak Hot Lava', 'Makanan', 18000, 25, 'ayam-kocak-hot-lava.jpg'),
(9, 2, 'Chicken Katsu', 'Makanan', 17000, 20, 'chicken-katsu.jpg'),
(10, 2, 'Nasi Ayam Goreng', 'Makanan', 15000, 20, 'nasi-ayam-goreng.jpg'),
(11, 2, 'Nasi Soto Ayam', 'Makanan', 12000, 25, 'nasi-soto-ayam.jpg'),
(12, 2, 'Nasi Rames', 'Makanan', 13000, 25, 'nasi-rames.jpg'),
(13, 3, 'Nasi Goreng Spesial', 'Makanan', 14000, 25, 'nasi-goreng-spesial.jpg'),
(14, 3, 'Nasi Rica-rica Ayam', 'Makanan', 15000, 20, 'nasi-rica-rica-ayam.jpg'),
(15, 3, 'Mie Goreng', 'Makanan', 12000, 20, 'mie-goreng.jpg'),
(16, 3, 'Seblak Pedas', 'Makanan', 13000, 20, 'seblak-pedas.jpg'),
(17, 3, 'Cilok Goreng', 'Camilan', 7000, 30, 'cilok-goreng.jpg'),
(18, 3, 'Cireng Isi', 'Camilan', 8000, 30, 'cireng-isi.jpg'),
(19, 3, 'Kentang Goreng', 'Camilan', 10000, 25, 'kentang-goreng.jpg'),
(20, 4, 'Es Teh Manis', 'Minuman', 4000, 60, 'es-teh-manis.jpg'),
(21, 4, 'Es Kopi Susu', 'Minuman', 8000, 30, 'es-kopi-susu.jpg'),
(22, 4, 'Matcha Latte', 'Minuman', 12000, 25, 'matcha-latte.jpg'),
(23, 4, 'Thai Tea', 'Minuman', 8000, 30, 'thai-tea.jpg'),
(24, 4, 'Es Jeruk', 'Minuman', 6000, 40, 'es-jeruk.jpg'),
(25, 4, 'Dubai Chewy Cookie', 'Dessert', 18000, 15, 'dubai-chewy-cookie.jpg'),
(26, 4, 'Brownies', 'Dessert', 12000, 20, 'brownies.jpg'),
(27, 4, 'Banana Pudding', 'Dessert', 10000, 20, 'banana-pudding.jpg'),
(28, 4, 'Croffle', 'Dessert', 15000, 15, 'croffle.jpg');

INSERT INTO pesanan (id, kode, id_user, id_penjual, tanggal, jam_ambil, total, status, catatan, metode, bayar) VALUES
(1, 'KTN-1001', 5, 1, CURDATE(), '11:30-11:45', 16000, 'menunggu', 'Sambal dipisah', 'qris', 'dibayar'),
(2, 'KTN-1002', 6, 2, CURDATE(), '12:00-12:15', 27000, 'dimasak', '', 'transfer', 'lunas'),
(3, 'KTN-1003', 5, 4, CURDATE(), '12:00-12:15', 20000, 'selesai', '', 'qris', 'lunas'),
(4, 'KTN-1004', 6, 3, CURDATE(), '12:30-12:45', 14000, 'menunggu', '', 'transfer', 'belum');

INSERT INTO detail_pesanan (id_pesanan, id_menu, nama_menu, harga, jumlah) VALUES
(1, 1, 'Lontong Opor Ayam', 13000, 1),
(1, 6, 'Peyek Kacang', 3000, 1),
(2, 7, 'Ayam Geprek', 15000, 1),
(2, 11, 'Nasi Soto Ayam', 12000, 1),
(3, 21, 'Es Kopi Susu', 8000, 1),
(3, 26, 'Brownies', 12000, 1),
(4, 13, 'Nasi Goreng Spesial', 14000, 1);
