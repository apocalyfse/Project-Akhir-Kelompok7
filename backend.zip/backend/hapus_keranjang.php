<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}

$id_menu = $_GET['id'];
unset($_SESSION['keranjang'][$id_menu]);

header("Location: ../keranjang.php");
?>
