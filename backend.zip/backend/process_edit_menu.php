<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id        = (int)$_POST['id'];
$id_stan   = $_SESSION['id_stan'];
$nama_menu = mysqli_real_escape_string($connect, $_POST['nama_menu']);
$kategori  = mysqli_real_escape_string($connect, $_POST['kategori']);
$harga     = (int)$_POST['harga'];
$stok      = (int)$_POST['stok'];

// id_stan di WHERE memastikan penjual hanya bisa mengubah menu miliknya
$update = mysqli_query($connect, "UPDATE menu SET nama_menu='$nama_menu', kategori='$kategori', harga=$harga, stok=$stok
                                  WHERE id=$id AND id_stan=$id_stan");
if ($update) {
    header("Location: ../menu.php?message=menu_edited");
} else {
    header("Location: ../menu.php?message=failed");
}
?>
