<?php
session_start();
session unset();
session_destroy();
header("Location: ../login.php?message=logout");
?>
