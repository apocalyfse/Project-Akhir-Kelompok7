<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

$id      = (int)$_GET['id'];
$id_user = $_SESSION['id'];

// hanya pesanan sendiri yang masih "menunggu" yang boleh dibatalkan
$cek = mysqli_query($connect, "SELECT id FROM pesanan WHERE id=$id AND id_user=$id_user AND status='menunggu'");
if (mysqli_num_rows($cek) == 1) {
    // stok dikembalikan
    mysqli_query($connect, "UPDATE menu JOIN detail_pesanan ON detail_pesanan.id_menu = menu.id
                            SET menu.stok = menu.stok + detail_pesanan.jumlah WHERE detail_pesanan.id_pesanan=$id");
    mysqli_query($connect, "UPDATE pesanan SET status='dibatalkan' WHERE id=$id");
    header("Location: ../riwayat.php?message=order_cancelled");
} else {
    header("Location: ../riwayat.php?message=failed");
}
?>
