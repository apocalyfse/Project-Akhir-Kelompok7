<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id         = (int)$_GET['id'];
$id_penjual = $_SESSION['id'];

mysqli_query($connect, "DELETE FROM menu WHERE id=$id AND id_penjual=$id_penjual");
header("Location: ../menu.php?message=menu_deleted");
?>



