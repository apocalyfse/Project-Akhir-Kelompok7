<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id      = (int)$_GET['id'];
$id_stan = $_SESSION['id_stan'];

mysqli_query($connect, "DELETE FROM menu WHERE id=$id AND id_stan=$id_stan");
header("Location: ../menu.php?message=menu_deleted");
?>
