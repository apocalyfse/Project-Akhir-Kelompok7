<?php
session_start();
include 'connect.php';

$username = trim($_POST['username']);
$password = trim($_POST['password']);

$username = mysqli_real_escape_string($connect, $username);
$password = mysqli_real_escape_string($connect, $password);

$query = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($connect, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);

    if ($row['password'] == $password) {


        $_SESSION['status'] = true;
        $_SESSION['username'] = $row['username'];
        $_SESSION['id'] = $row['id'];
        $_SESSION['role'] = $row['role'];

        if ($row['role'] == 'penjual') {
            header("Location: ../pesanan.php");
        } else {
            header("Location: ../index.php");
        }
        exit();

    } else {
    
        header("Location: ../login.php?message=false");
        exit();
    }

} else {

    header("Location: ../login.php?message=false");
    exit();
}
?>