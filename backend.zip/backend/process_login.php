<?php
session_start();
include 'connect.php';

$username = mysqli_real_escape_string($connect, $_POST['username']);
$password = mysqli_real_escape_string($connect, $_POST['password']);

$query = mysqli_query($connect, "SELECT * FROM users WHERE email='$username' AND password='$password'");
$data  = mysqli_fetch_assoc($query);

if ($data) {
    $_SESSION['status']   = true;
    $_SESSION['username'] = $data['nama'];
    $_SESSION['id']       = $data['id'];
    $_SESSION['role']     = $data['role'];

    if ($data['role'] == 'penjual') {
        // Simpan id stan milik penjual ini
        $id_user = $data['id'];
        $q_stan  = mysqli_query($connect, "SELECT id FROM stan WHERE id_user=$id_user");
        $stan    = mysqli_fetch_assoc($q_stan);
        $_SESSION['id_stan'] = $stan['id'];
        header("Location: ../pesanan.php");
    } else {
        header("Location: ../index.php");
    }
} else {
    header("Location: ../login.php?message=false");
}
?>
