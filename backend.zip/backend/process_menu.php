<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id         = (int)$_POST['id'];      // 0 = menu baru, selain itu = edit menu
$id_penjual = $_SESSION['id'];
$nama_menu  = mysqli_real_escape_string($connect, $_POST['nama_menu']);
$kategori   = mysqli_real_escape_string($connect, $_POST['kategori']);
$harga      = (int)$_POST['harga'];
$stok       = (int)$_POST['stok'];
$foto       = upload_foto($_FILES['foto']);

if ($id == 0) {
    $simpan = mysqli_query($connect, "INSERT INTO menu (id_penjual, nama_menu, kategori, harga, stok, foto)
                                      VALUES ($id_penjual, '$nama_menu', '$kategori', $harga, $stok, '$foto')");
    header("Location: ../menu.php?message=menu_added");
} else {
    // foto hanya diganti kalau ada file baru
    $sql_foto = "";
    if ($foto != "") {
        $sql_foto = ", foto='$foto'";
    }
    // id_penjual di WHERE supaya penjual hanya bisa mengubah menu miliknya
    mysqli_query($connect, "UPDATE menu SET nama_menu='$nama_menu', kategori='$kategori', harga=$harga, stok=$stok $sql_foto
                            WHERE id=$id AND id_penjual=$id_penjual");
    header("Location: ../menu.php?message=menu_edited");
}
?>
