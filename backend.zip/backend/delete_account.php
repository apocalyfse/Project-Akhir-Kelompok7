<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
include 'connect.php';

$id = $_GET['id'];

// Hanya boleh menghapus akun sendiri
if ($id == $_SESSION['id']) {
    mysqli_query($connect, "DELETE FROM users WHERE id=$id");
    session_destroy();
    header("Location: ../login.php?message=account_deleted");
} else {
    header("Location: ../index.php");
}
?>
