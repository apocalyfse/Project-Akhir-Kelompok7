<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

if (empty($_SESSION['keranjang'])) {
    header("Location: ../keranjang.php?message=cart_empty");
    exit();
}

$id_user    = $_SESSION['id'];
$id_stan    = $_SESSION['id_stan_keranjang'];
$id_slot    = (int)$_POST['id_slot'];
$tanggal    = date('Y-m-d', strtotime($_POST['tanggal']));
$catatan    = mysqli_real_escape_string($connect, $_POST['catatan']);
$keranjang  = $_SESSION['keranjang'];

// 1. Cek stok semua menu dan hitung total
$total = 0;
$items = array();
foreach ($keranjang as $id_menu => $jumlah) {
    $query = mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu AND id_stan=$id_stan");
    $menu  = mysqli_fetch_assoc($query);
    if (!$menu || $menu['stok'] < $jumlah) {
        header("Location: ../keranjang.php?message=stok_habis");
        exit();
    }
    $total   += $menu['harga'] * $jumlah;
    $items[]  = array('menu' => $menu, 'jumlah' => $jumlah);
}

// 2. Cek slot masih ada kuota dan belum lewat
$q_slot = mysqli_query($connect, "SELECT slot.*,
            (SELECT COUNT(*) FROM pesanan WHERE id_slot=slot.id AND id_stan=$id_stan AND tanggal='$tanggal' AND status!='dibatalkan') AS terpakai
            FROM slot WHERE id=$id_slot");
$slot = mysqli_fetch_assoc($q_slot);
if (!$slot || $slot['terpakai'] >= $slot['kuota'] || $tanggal < date('Y-m-d') ||
    ($tanggal == date('Y-m-d') && $slot['jam_mulai'] <= date('H:i:s'))) {
    header("Location: ../checkout.php?tanggal=$tanggal&message=slot_full");
    exit();
}

// 3. Buat kode pengambilan yang belum dipakai
do {
    $kode = "KTN-" . rand(1000, 9999);
    $cek  = mysqli_query($connect, "SELECT id FROM pesanan WHERE kode='$kode'");
} while (mysqli_num_rows($cek) > 0);

// 4. Simpan pesanan, isi pesanan, dan kurangi stok
mysqli_query($connect, "INSERT INTO pesanan (kode, id_user, id_stan, id_slot, tanggal, total, status, catatan)
                        VALUES ('$kode', $id_user, $id_stan, $id_slot, '$tanggal', $total, 'menunggu', '$catatan')");
$id_pesanan = mysqli_insert_id($connect);

foreach ($items as $item) {
    $menu   = $item['menu'];
    $jumlah = $item['jumlah'];
    $id_menu   = $menu['id'];
    $nama_menu = mysqli_real_escape_string($connect, $menu['nama_menu']);
    $harga     = $menu['harga'];
    mysqli_query($connect, "INSERT INTO detail_pesanan (id_pesanan, id_menu, nama_menu, harga, jumlah)
                            VALUES ($id_pesanan, $id_menu, '$nama_menu', $harga, $jumlah)");
    mysqli_query($connect, "UPDATE menu SET stok = stok - $jumlah WHERE id=$id_menu");
}

unset($_SESSION['keranjang']);
unset($_SESSION['id_stan_keranjang']);
header("Location: ../riwayat.php?message=order_success");
?>
