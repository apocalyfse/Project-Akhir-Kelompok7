<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

$id_user   = $_SESSION['id'];
$tanggal   = date('Y-m-d', strtotime($_POST['tanggal']));
$jam_ambil = $_POST['jam_ambil'];
$metode    = $_POST['metode'];
$catatan   = mysqli_real_escape_string($connect, $_POST['catatan']);
if ($metode != 'transfer') {
    $metode = 'qris';
}

// 1. cek menu yang dipilih: harus ada di keranjang, stok cukup, dan dari satu kedai
$total      = 0;
$id_penjual = 0;
$pilihan    = array();
if (isset($_POST['pilih'])) {
    $pilihan = $_POST['pilih'];
}
if (count($pilihan) == 0) {
    header("Location: ../keranjang.php?message=pilih_kosong");
    exit();
}
foreach ($pilihan as $id_menu) {
    $id_menu = (int)$id_menu;
    $query   = mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu");
    $menu    = mysqli_fetch_assoc($query);
    if (!isset($_SESSION['keranjang'][$id_menu]) || !$menu) {
        header("Location: ../keranjang.php?message=pilih_kosong");
        exit();
    }
    if ($id_penjual != 0 && $id_penjual != $menu['id_penjual']) {
        header("Location: ../keranjang.php?message=pilih_kosong");
        exit();
    }
    if ($menu['stok'] < $_SESSION['keranjang'][$id_menu]) {
        header("Location: ../keranjang.php?message=stok_habis");
        exit();
    }
    $id_penjual = $menu['id_penjual'];
    $total      = $total + $menu['harga'] * $_SESSION['keranjang'][$id_menu];
}

// 2. cek jam pengambilan: harus ada, belum penuh, dan belum lewat
$slot_ada = in_array($jam_ambil, $daftar_slot);
$q_slot   = mysqli_query($connect, "SELECT COUNT(*) AS jumlah FROM pesanan WHERE id_penjual=$id_penjual AND tanggal='$tanggal' AND jam_ambil='$jam_ambil' AND status!='dibatalkan'");
$terpakai = mysqli_fetch_assoc($q_slot)['jumlah'];
$lewat    = false;
if ($tanggal < date('Y-m-d') || ($tanggal == date('Y-m-d') && substr($jam_ambil, 0, 5) <= date('H:i'))) {
    $lewat = true;
}
if (!$slot_ada || $terpakai >= $kuota_slot || $lewat) {
    $link = "../checkout.php?tanggal=$tanggal&message=slot_full";
    foreach ($pilihan as $id_menu) {
        $link = $link . "&pilih[]=" . (int)$id_menu;
    }
    header("Location: " . $link);
    exit();
}

// 3. buat kode pengambilan yang belum dipakai
$kode = "KTN-" . rand(1000, 9999);
$cek  = mysqli_query($connect, "SELECT id FROM pesanan WHERE kode='$kode'");
while (mysqli_num_rows($cek) > 0) {
    $kode = "KTN-" . rand(1000, 9999);
    $cek  = mysqli_query($connect, "SELECT id FROM pesanan WHERE kode='$kode'");
}

// 4. simpan pesanan dan isinya, kurangi stok, lalu hapus dari keranjang
mysqli_query($connect, "INSERT INTO pesanan (kode, id_user, id_penjual, tanggal, jam_ambil, total, catatan, metode)
                        VALUES ('$kode', $id_user, $id_penjual, '$tanggal', '$jam_ambil', $total, '$catatan', '$metode')");
$id_pesanan = mysqli_insert_id($connect);

foreach ($pilihan as $id_menu) {
    $id_menu   = (int)$id_menu;
    $jumlah    = $_SESSION['keranjang'][$id_menu];
    $query     = mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu");
    $menu      = mysqli_fetch_assoc($query);
    $nama_menu = mysqli_real_escape_string($connect, $menu['nama_menu']);
    $harga     = $menu['harga'];

    mysqli_query($connect, "INSERT INTO detail_pesanan (id_pesanan, id_menu, nama_menu, harga, jumlah)
                            VALUES ($id_pesanan, $id_menu, '$nama_menu', $harga, $jumlah)");
    mysqli_query($connect, "UPDATE menu SET stok = stok - $jumlah WHERE id=$id_menu");
    unset($_SESSION['keranjang'][$id_menu]);
}

header("Location: ../riwayat.php?message=order_success");
?>
