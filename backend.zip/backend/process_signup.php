<?php
include 'connect.php';

$username  = mysqli_real_escape_string($connect, $_POST['username']);
$email     = mysqli_real_escape_string($connect, $_POST['email']);
$password  = mysqli_real_escape_string($connect, $_POST['password']);
$role      = $_POST['role'];
$nama_stan = mysqli_real_escape_string($connect, $_POST['nama_stan']);

if ($role != 'penjual') {
    $role = 'pelanggan';
}
if ($nama_stan == '') {
    $nama_stan = "Stan " . $username;
}

// Cek username sudah dipakai atau belum
$cek = mysqli_query($connect, "SELECT id FROM users WHERE username='$username'");
if (mysqli_num_rows($cek) > 0) {
    header("Location: ../signup.php?message=used_username");
    exit();
}

$simpan = mysqli_query($connect, "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')");

if ($simpan) {
    // Kalau daftar sebagai penjual, sekalian buat stannya
    if ($role == 'penjual') {
        $id_user = mysqli_insert_id($connect);
        mysqli_query($connect, "INSERT INTO stan (id_user, nama_stan) VALUES ($id_user, '$nama_stan')");
    }
    header("Location: ../login.php?message=account_created");
} else {
    header("Location: ../signup.php?message=failed");
}
?>
