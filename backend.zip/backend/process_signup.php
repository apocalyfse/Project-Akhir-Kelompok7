<?php
include 'connect.php';

$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$role = $_POST['role'];
$nama_stan = trim($_POST['nama_stan']);

$username = mysqli_real_escape_string($connect, $username);
$email = mysqli_real_escape_string($connect, $email);
$password = mysqli_real_escape_string($connect, $password);
$nama_stan = mysqli_real_escape_string($connect, $nama_stan);

if ($role != 'penjual') {
    $role = 'pelanggan';
    $nama_stan = '';
} else if ($nama_stan == '') {
    $nama_stan = 'Kedai ' . $username;
}

$cek = mysqli_query($connect, "SELECT * FROM users WHERE username='$username'");

if (mysqli_num_rows($cek) > 0) {
    header("Location: ../signup.php?message=used_username");
    exit();
} else {


    $query = mysqli_query($connect, "INSERT INTO users (username, email, password, role, nama_stan)
    VALUES ('$username', '$email', '$password', '$role', '$nama_stan')");

    if ($query) {
        header("Location: ../login.php?message=account_created");
        exit();
        
    } else {
        header("Location: ../signup.php?message=failed");
        exit();
    }
}
?>
