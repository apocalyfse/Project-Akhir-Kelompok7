<?php
date_default_timezone_set('Asia/Jakarta');

$hostname = "localhost";
$username = "root";
$password = "";
$database = "db_kantinku";

$connect = mysqli_connect($hostname, $username, $password, $database);

if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$daftar_slot = array(
    '07:30-07:45',
    '09:30-09:45',
    '11:30-11:45',
    '12:00-12:15',
    '12:30-12:45',
    '13:00-13:15'
);

$kuota_slot = 8;

$daftar_kategori = array(
    'Makanan',
    'Minuman',
    'Camilan',
    'Dessert'
);

$warna_bayar = array(
    'belum' => 'secondary',
    'dibayar' => 'info',
    'lunas' => 'success'
);

$teks_bayar = array(
    'belum' => 'Belum bayar',
    'dibayar' => 'Menunggu konfirmasi',
    'lunas' => 'Lunas'
);

$warna_status = array(
    'menunggu' => 'warning',
    'dimasak' => 'info',
    'siap' => 'success',
    'selesai' => 'secondary',
    'dibatalkan' => 'danger'
);

function esc($teks) {
    global $connect;
    return mysqli_real_escape_string($connect, $teks);
}


function e($teks) {
    return htmlspecialchars($teks);
}

// mengubah angka menjadi format rupiah
function rupiah($angka) {
    return "Rp " . number_format($angka, 0, ",", ".");
}

// menampilkan foto menu
function foto_menu($foto) {
    if ($foto != '' && file_exists(__DIR__ . '/../uploads/' . $foto)) {
        return 'uploads/' . $foto;
    }

    return '';
}

// fungsi upload gambar
function upload_foto($file) {

    if ($file['error'] != 0 || $file['size'] > 2 * 1024 * 1024) {
        return '';
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, array('jpg', 'jpeg', 'png', 'webp')) || getimagesize($file['tmp_name']) === false) {
        return '';
    }

    $nama = time() . rand(100, 999) . '.' . $ext;

    move_uploaded_file($file['tmp_name'], __DIR__ . '/../uploads/' . $nama);

    return $nama;
}

// mengambil menu yang dipilih dari keranjang
function ambil_pilihan($pilih) {
    global $connect;

    $hasil = array();
    $id_penjual = 0;

    if (!is_array($pilih) || empty($pilih)) {
        return false;
    }

    foreach ($pilih as $id_menu) {

        $id_menu = (int)$id_menu;

        if (!isset($_SESSION['keranjang'][$id_menu])) {
            return false;
        }

        $m = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu"));

        if (!$m || ($id_penjual != 0 && $id_penjual != $m['id_penjual'])) {
            return false;
        }

        $id_penjual = $m['id_penjual'];
        $m['jumlah'] = $_SESSION['keranjang'][$id_menu];

        $hasil[] = $m;
    }

    return $hasil;
}
?>
