<?php
date_default_timezone_set('Asia/Jakarta');

$hostname = "localhost";
$username = "root";
$password = "";
$database = "db_kantinku";
// Koneksi ke database (sesuaikan host, username, password dengan MySQL kamu)
$connect = mysqli_connect($hostname, $username, $password, $database);

if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ubah angka jadi format rupiah, contoh: 15000 -> Rp 15.000
function rupiah($angka) {
    return "Rp " . number_format($angka, 0, ",", ".");
}

// Warna badge Bootstrap untuk status pesanan
function warna_status($status) {
    if ($status == 'menunggu') return 'warning text-dark';
    if ($status == 'dimasak')  return 'info text-dark';
    if ($status == 'siap')     return 'success';
    if ($status == 'selesai')  return 'secondary';
    return 'danger';
}
?>
