<?php
session_start();

if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}

include 'connect.php';

$id = $_SESSION['id'];

$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);

$username = mysqli_real_escape_string($connect, $username);
$email = mysqli_real_escape_string($connect, $email);
$password = mysqli_real_escape_string($connect, $password);

$cek = mysqli_query($connect, "SELECT * FROM users WHERE username='$username' AND id!='$id'");

if (mysqli_num_rows($cek) > 0) {
    header("Location: ../edit_account.php?message=used_username");
    exit();
}

$query = "UPDATE users SET username='$username', email='$email'";

if ($_SESSION['role'] == 'penjual') {
    $nama_stan = mysqli_real_escape_string($connect, $_POST['nama_stan']);
    $rekening = mysqli_real_escape_string($connect, $_POST['rekening']);

    $query .= ", nama_stan='$nama_stan', rekening='$rekening'";

    if (isset($_FILES['qris']) && $_FILES['qris']['error'] == 0) {
        $qris = upload_foto($_FILES['qris']);

        if ($qris != '') {
            $query .= ", qris='$qris'";
        }
    }
}

if ($password != '') {
    $query .= ", password='$password'";
}

$update = mysqli_query($connect, $query . " WHERE id='$id'");

if ($update) {
    $_SESSION['username'] = $_POST['username'];
    header("Location: ../edit_account.php?message=edit_successful");
    exit();
} else {
    header("Location: ../edit_account.php?message=failed");
    exit();
}
?>
