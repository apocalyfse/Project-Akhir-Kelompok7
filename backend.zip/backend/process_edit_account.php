<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
include 'connect.php';

$id       = $_SESSION['id'];
$username = mysqli_real_escape_string($connect, $_POST['username']);
$email    = mysqli_real_escape_string($connect, $_POST['email']);
$password = mysqli_real_escape_string($connect, $_POST['password']);

// Cek username dipakai akun lain (id berbeda)
$cek = mysqli_query($connect, "SELECT id FROM users WHERE username='$username' AND id!=$id");
if (mysqli_num_rows($cek) > 0) {
    header("Location: ../edit_account.php?message=used_username");
    exit();
}

if ($password == '') {
    $update = mysqli_query($connect, "UPDATE users SET username='$username', email='$email' WHERE id=$id");
} else {
    $update = mysqli_query($connect, "UPDATE users SET username='$username', email='$email', password='$password' WHERE id=$id");
}

if ($update) {
    $_SESSION['username'] = $username;
    header("Location: ../edit_account.php?message=edit_successful");
} else {
    header("Location: ../edit_account.php?message=failed");
}
?>
