<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id      = (int)$_GET['id'];
$status  = $_GET['status'];
$id_stan = $_SESSION['id_stan'];

// Pesanan harus milik stan penjual yang login
$query = mysqli_query($connect, "SELECT * FROM pesanan WHERE id=$id AND id_stan=$id_stan");
$p     = mysqli_fetch_assoc($query);

// Urutan status: menunggu -> dimasak -> siap -> selesai
$berikutnya = array('menunggu' => 'dimasak', 'dimasak' => 'siap', 'siap' => 'selesai');

if ($p) {
    if ($status == 'dibatalkan' && ($p['status'] == 'menunggu' || $p['status'] == 'dimasak')) {
        // Dibatalkan penjual: stok dikembalikan
        mysqli_query($connect, "UPDATE menu JOIN detail_pesanan ON detail_pesanan.id_menu = menu.id
                                SET menu.stok = menu.stok + detail_pesanan.jumlah WHERE detail_pesanan.id_pesanan=$id");
        mysqli_query($connect, "UPDATE pesanan SET status='dibatalkan' WHERE id=$id");
    } elseif (isset($berikutnya[$p['status']]) && $berikutnya[$p['status']] == $status) {
        mysqli_query($connect, "UPDATE pesanan SET status='$status' WHERE id=$id");
    }
}
header("Location: ../pesanan.php?message=status_updated");
?>
