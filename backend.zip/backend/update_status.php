<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id         = (int)$_GET['id'];
$aksi       = $_GET['aksi'];
$id_penjual = $_SESSION['id'];

// pesanan harus milik kedai penjual yang login
$query = mysqli_query($connect, "SELECT * FROM pesanan WHERE id=$id AND id_penjual=$id_penjual");
$p     = mysqli_fetch_assoc($query);
if (!$p) {
    header("Location: ../pesanan.php");
    exit();
}

$message = "status_updated";
if ($aksi == 'lunas' && $p['bayar'] == 'dibayar') {
    mysqli_query($connect, "UPDATE pesanan SET bayar='lunas' WHERE id=$id");
    $message = "lunas_ok";
} elseif ($aksi == 'masak' && $p['status'] == 'menunggu') {
    if ($p['bayar'] == 'lunas') {
        mysqli_query($connect, "UPDATE pesanan SET status='dimasak' WHERE id=$id");
    } else {
        $message = "belum_lunas";
    }
} elseif ($aksi == 'siap' && $p['status'] == 'dimasak') {
    mysqli_query($connect, "UPDATE pesanan SET status='siap' WHERE id=$id");
} elseif ($aksi == 'selesai' && $p['status'] == 'siap') {
    mysqli_query($connect, "UPDATE pesanan SET status='selesai' WHERE id=$id");
} elseif ($aksi == 'batal' && ($p['status'] == 'menunggu' || $p['status'] == 'dimasak')) {
    // stok dikembalikan
    mysqli_query($connect, "UPDATE menu JOIN detail_pesanan ON detail_pesanan.id_menu = menu.id
                            SET menu.stok = menu.stok + detail_pesanan.jumlah WHERE detail_pesanan.id_pesanan=$id");
    mysqli_query($connect, "UPDATE pesanan SET status='dibatalkan' WHERE id=$id");
}

header("Location: ../pesanan.php?tanggal=" . $p['tanggal'] . "&message=" . $message);
?>
