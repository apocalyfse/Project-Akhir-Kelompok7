<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

$id      = (int)$_POST['id'];
$id_user = $_SESSION['id'];

// pesanan harus milik sendiri, belum lunas, dan tidak dibatalkan
$cek = mysqli_query($connect, "SELECT id FROM pesanan WHERE id=$id AND id_user=$id_user AND bayar!='lunas' AND status!='dibatalkan'");
if (mysqli_num_rows($cek) == 0) {
    header("Location: ../riwayat.php?message=failed");
    exit();
}

$bukti = upload_foto($_FILES['bukti']);
if ($bukti == "") {
    header("Location: ../riwayat.php?message=bayar_gagal");
} else {
    mysqli_query($connect, "UPDATE pesanan SET bukti='$bukti', bayar='dibayar' WHERE id=$id");
    header("Location: ../riwayat.php?message=bukti_terkirim");
}
?>
