<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

$id_menu = (int)$_POST['id_menu'];
$query   = mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu");
$menu    = mysqli_fetch_assoc($query);

if (!$menu || $menu['stok'] <= 0) {
    header("Location: ../index.php?message=stok_habis");
    exit();
}

// Keranjang hanya boleh berisi menu dari satu stan
if (!empty($_SESSION['keranjang']) && $_SESSION['id_stan_keranjang'] != $menu['id_stan']) {
    header("Location: ../index.php?message=beda_stan");
    exit();
}

// Keranjang disimpan di session: $_SESSION['keranjang'][id_menu] = jumlah
$sudah = isset($_SESSION['keranjang'][$id_menu]) ? $_SESSION['keranjang'][$id_menu] : 0;
if ($sudah + 1 > $menu['stok']) {
    header("Location: ../index.php?message=stok_habis");
    exit();
}
$_SESSION['keranjang'][$id_menu] = $sudah + 1;
$_SESSION['id_stan_keranjang']   = $menu['id_stan'];

header("Location: ../index.php?message=cart_added");
?>
