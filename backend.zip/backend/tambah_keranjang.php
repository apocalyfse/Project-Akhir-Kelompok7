<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'pelanggan') {
    header("Location: ../pesanan.php");
    exit();
}
include 'connect.php';

$id_menu = (int)$_POST['id_menu'];
$query   = mysqli_query($connect, "SELECT * FROM menu WHERE id=$id_menu");
$menu    = mysqli_fetch_assoc($query);

// keranjang disimpan di session: $_SESSION['keranjang'][id_menu] = jumlah
$jumlah = 0;
if (isset($_SESSION['keranjang'][$id_menu])) {
    $jumlah = $_SESSION['keranjang'][$id_menu];
}

if (!$menu || $jumlah + 1 > $menu['stok']) {
    header("Location: ../index.php?message=stok_habis");
    exit();
}

$_SESSION['keranjang'][$id_menu] = $jumlah + 1;
header("Location: ../index.php?message=cart_added");
?>
