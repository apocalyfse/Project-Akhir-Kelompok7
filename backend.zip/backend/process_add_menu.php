<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != true) {
    header("Location: ../login.php?message=not_logged_in");
    exit();
}
if ($_SESSION['role'] != 'penjual') {
    header("Location: ../index.php");
    exit();
}
include 'connect.php';

$id_stan   = $_SESSION['id_stan'];
$nama_menu = mysqli_real_escape_string($connect, $_POST['nama_menu']);
$kategori  = mysqli_real_escape_string($connect, $_POST['kategori']);
$harga     = (int)$_POST['harga'];
$stok      = (int)$_POST['stok'];

$simpan = mysqli_query($connect, "INSERT INTO menu (id_stan, nama_menu, kategori, harga, stok)
                                  VALUES ($id_stan, '$nama_menu', '$kategori', $harga, $stok)");
if ($simpan) {
    header("Location: ../menu.php?message=menu_added");
} else {
    header("Location: ../menu.php?message=failed");
}
?>
